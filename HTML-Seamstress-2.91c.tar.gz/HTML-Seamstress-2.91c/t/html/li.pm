package html::li;
use strict;
use warnings;
use base qw(HTML::Seamstress);

my $tree;

my ($store_items);
sub new {
$tree = __PACKAGE__->new_from_file('/home/terry/perl/hax/HTML-Seamstress-2.6/t/html/li.html');

# content_accessors
;

# highlander_accessors
;

# iter_accessors
$store_items = $tree->look_down(id => q/store_items/);

$tree;
}

# content subs

# highlander subs

# iter subs

sub store_items {
   my $tree = shift;
   if (@_) {
      $store_items->iter(@_);
      return $tree
   } else {
      return $store_items
   }

}



sub tree {
  $tree
}


1;

