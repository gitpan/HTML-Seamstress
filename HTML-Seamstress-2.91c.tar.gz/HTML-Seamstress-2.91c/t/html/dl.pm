package html::dl;
use strict;
use warnings;
use base qw(HTML::Seamstress);

my $tree;

my ($service_plan);
sub new {
$tree = __PACKAGE__->new_from_file('/home/terry/perl/hax/HTML-Seamstress-2.6/t/html/dl.html');

# content_accessors
;

# highlander_accessors
;

# iter_accessors
;

# dual_iter_accessors
$service_plan = $tree->look_down(id => q/service_plan/);

$tree;
}

# content subs

# highlander subs

# iter subs


# dual_iter subs

sub service_plan {
   my $tree = shift;
   if (@_) {
      $service_plan->dual_iter(\@_);
      return $tree
   } else {
      return $service_plan
   }

}



sub tree {
  $tree
}


1;

